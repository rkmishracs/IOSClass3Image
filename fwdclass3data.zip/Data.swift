//
//  Data.swift
//  CoffeeShop
//
//  Created by Harshit Gajjar on 9/14/19.
//  Copyright © 2019 ThinkX. All rights reserved.
//

import UIKit



var hotCoffeeNames = ["Caffè Americano", "Caffè Latte", "Caffè Mocha",
"Cappuccino", "Caramel Cloud Macchiato", "Caramel Macchiato",
"Cinnamon Dolce Latte", "Cocoa Cloud Macchiato", "Espresso", "Espresso Con Panna"]

var hotCoffeeBackground = [#colorLiteral(red: 0.9254901961, green: 0.8078431373, blue: 0.6509803922, alpha: 1),#colorLiteral(red: 0.6823529412, green: 0.537254902, blue: 0.4352941176, alpha: 1),#colorLiteral(red: 0.9607843137, green: 0.8705882353, blue: 0.5843137255, alpha: 1),#colorLiteral(red: 0.8235294118, green: 0.6941176471, blue: 0.6, alpha: 1),#colorLiteral(red: 0.8392156863, green: 0.7803921569, blue: 0.7058823529, alpha: 1),#colorLiteral(red: 0.968627451, green: 0.9058823529, blue: 0.8078431373, alpha: 1), #colorLiteral(red: 0.9254901961, green: 0.8078431373, blue: 0.6509803922, alpha: 1),#colorLiteral(red: 0.6823529412, green: 0.537254902, blue: 0.4352941176, alpha: 1),#colorLiteral(red: 0.9607843137, green: 0.8705882353, blue: 0.5843137255, alpha: 1),#colorLiteral(red: 0.8235294118, green: 0.6941176471, blue: 0.6, alpha: 1)]

var hotCoffeeData = [HotCoffee(name: "Caffè Americano", image: "1"),
HotCoffee(name: "Caffè Latte", image: "2"),
HotCoffee(name: "Caffè Mocha", image: "3"),
HotCoffee(name: "Cappuccino", image: "4"),
HotCoffee(name: "Caramel Cloud Macchiato", image: "5"),
HotCoffee(name: "Caramel Macchiato", image: "6"),
HotCoffee(name: "Cinnamon Dolce Latte", image: "8"),
HotCoffee(name: "Cocoa Cloud Macchiato", image: "7"),
HotCoffee(name: "Espresso", image: "9"),
HotCoffee(name: "Espresso Con Panna", image: "10")]
